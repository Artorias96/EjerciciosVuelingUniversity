﻿namespace GNBCurrencies.Models
{
    public class ProductsConversionsModel
    {
        public string Sku { get; set; }

        public decimal Amount { get; set; }

        public string Currency { get; set; }
    }
}
